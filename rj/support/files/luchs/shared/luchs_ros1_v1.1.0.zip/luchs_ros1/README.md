# luchs_ros1

**ROS 1 software for the Luchs family of robot chassis: Luchs A and Luchs B.**
Chassis by **RJ Tech Limited** · Software by **TerraAgent Robotics (TAR)**

`luchs_ros1` is the ROS 1 (Noetic) counterpart of `luchs_ros2`. Both are built on the same `luchs_sdk` (identical sources): the same CAN protocols, watchdogs, heartbeat, live limits, kinematics and simulators, the same topics, frames and services. Parameter names use `/` where ROS 2 uses `.` (`geometry/wheelbase`).

| | |
|---|---|
| ROS 1 | Noetic (Ubuntu 20.04). Melodic: not tested (C++17 required) |
| Interface | CAN 2.0, SocketCAN (any Linux USB-CAN adapter) |
| Chassis | **Luchs A**: A-DF · A-FA · A-DA · A-4WS (protocol v1.1)<br>**Luchs B**: single / dual Ackermann (LCI v1.0; VCU upper interface V2.6 for units before LCI firmware) |
| Licence | Apache-2.0 |

| Package | What it is |
|---|---|
| `luchs_sdk` | ROS-free C++17 library (plain CMake package), identical to `luchs_ros2/luchs_sdk`, with `luchs_cli` |
| `luchs_msgs` | `ChassisState`, `SafetyState`, `LampCommand`, `DriveCommand`, `SetMotionModel`, `SetPayloadPower`, `SetSpeedLimit` (same definitions as ROS 2) |
| `luchs_driver` | the ROS 1 node `luchs_driver_node`, parameter files `config/luchs_a_<build>.yaml`, `config/luchs_b.yaml`, rostests |
| `luchs_description` | URDF / xacro for Luchs A and Luchs B (same files as ROS 2), `display.launch` |
| `luchs_bringup` | `luchs_a.launch`, `luchs_b.launch`, CAN setup script, udev rule, systemd units |
| `luchs_teleop` | gamepad configuration (Luchs A, Luchs B) |
| `luchs` | metapackage |
| `dbc`, `docs` | DBC files and protocol references (same as ROS 2) |

## Build

`luchs_sdk` is a plain CMake package, so use **catkin build** (catkin_tools) or `catkin_make_isolated`; plain `catkin_make` refuses mixed workspaces.

```bash
source /opt/ros/noetic/setup.bash
mkdir -p ~/luchs_ws/src && cd ~/luchs_ws/src
unzip luchs_ros1_v1.1.0.zip            # or git clone
cd ~/luchs_ws
rosdep install --from-paths src --ignore-src -y
catkin build                           # sudo apt install python3-catkin-tools
source devel/setup.bash
```

## Try it without a vehicle

```bash
roslaunch luchs_bringup luchs_b.launch dry_run:=true              # Luchs B (LCI)
roslaunch luchs_bringup luchs_a.launch build:=4ws dry_run:=true   # Luchs A-4WS
rostopic pub -r 20 /cmd_vel geometry_msgs/Twist '{linear: {x: 0.8}, angular: {z: 0.2}}'
rostopic echo /luchs_driver/state
roslaunch luchs_description display.launch config:=b              # model in RViz
```

## Connect the vehicle

```bash
sudo ./src/luchs_ros1/luchs_bringup/scripts/setup_can.sh can0     # 1 Mbit/s
roslaunch luchs_bringup luchs_a.launch build:=4ws can_interface:=can0
roslaunch luchs_bringup luchs_b.launch can_interface:=can0
roslaunch luchs_bringup luchs_b.launch protocol:=legacy_b         # Luchs B before LCI firmware
```

Wiring, bit rates and checks: `docs/can_setup.md`, `docs/protocol_luchs_a.md`, `docs/protocol_luchs_b.md`. **Before the first drive:** lift the wheels or clear the area, keep the emergency stop in reach, start with the default limits.

## ROS interface

| | Topic / service | Type |
|---|---|---|
| in | `cmd_vel` | `geometry_msgs/Twist` (or `TwistStamped`, `cmd_vel_stamped: true`) |
| in | `~drive_command` | `luchs_msgs/DriveCommand` (motion model, explicit steering angles) |
| in | `~lamps` | `luchs_msgs/LampCommand` |
| out | `odom` + TF `odom → base_footprint` | `nav_msgs/Odometry` |
| out | `joint_states` | `sensor_msgs/JointState` |
| out | `~state`, `~safety` | `luchs_msgs/ChassisState`, `SafetyState` |
| out | `battery_state` | `sensor_msgs/BatteryState` |
| out | `imu/data_raw` | `sensor_msgs/Imu` (Luchs B, LCI) |
| out | `/diagnostics` | `diagnostic_msgs/DiagnosticArray` |
| srv | `~reset_odometry`, `~set_motion_model` | `std_srvs/Trigger`, `luchs_msgs/SetMotionModel` |
| srv | `~estop`, `~park` | `std_srvs/SetBool` (Luchs B) |
| srv | `~set_payload_power`, `~set_speed_limit` | `luchs_msgs/SetPayloadPower`, `SetSpeedLimit` (Luchs B, LCI) |

Behaviour, safety functions, motion models and parameters are those of the ROS 2 driver: see its README and `luchs_driver/README.md` in `luchs_ros2`, reading `a.b` as `a/b`.

## Tests

```bash
catkin build && source devel/setup.bash
rostest luchs_driver dry_run_b.test    # Luchs B: odometry and IMU rates, drive, speed cap, e-stop latch
rostest luchs_driver dry_run_a.test    # Luchs A-4WS: odometry rate, drive
```

The SDK's unit tests (63) run in `luchs_ros2` (`colcon test --packages-select luchs_sdk`).

## Support

RJ Tech Limited · sales@rjtech-offroad.com · [rjtech-offroad.com](https://www.rjtech-offroad.com)
TerraAgent Robotics (TAR) · robot software and integration

When reporting a problem, include the driver log, `rostopic echo -n 1 /diagnostics`, the build (`df`/`fa`/`da`/`4ws`/`b`), the protocol and a short `candump -l can0` capture.
