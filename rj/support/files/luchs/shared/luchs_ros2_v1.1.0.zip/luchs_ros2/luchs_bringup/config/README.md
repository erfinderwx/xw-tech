Driver parameter files live in `luchs_driver/config/luchs_a_<build>.yaml`.
Copy one next to your application and pass it with `params_file:=/path/to/file.yaml`.
