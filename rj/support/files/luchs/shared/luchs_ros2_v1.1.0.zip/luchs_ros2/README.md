# luchs_ros2

**ROS 2 and C++ software for the Luchs family of robot chassis: Luchs A and Luchs B.**
Chassis by **RJ Tech Limited** · Software by **TerraAgent Robotics (TAR)**

`luchs_ros2` connects a Luchs chassis to your robot software over CAN. Publish a velocity on `cmd_vel`; the driver turns it into chassis commands, enforces speed, steering and acceleration limits, stops the vehicle when commands or feedback stop, and publishes odometry, TF, joint states, chassis and safety state, battery state and diagnostics. One code base for the whole Luchs family: the same topics, frames and services on Luchs A and Luchs B.

| | |
|---|---|
| ROS 2 | Jazzy (Ubuntu 24.04) · Humble (Ubuntu 22.04). ROS 1 Noetic: `luchs_ros1`, same SDK |
| Interface | CAN 2.0, SocketCAN (any Linux USB-CAN adapter) |
| Chassis | **Luchs A**: A-DF skid-steer · A-FA front Ackermann · A-DA dual Ackermann · A-4WS four-wheel steer<br>**Luchs B**: four hub motors, front + rear EPS, single or dual Ackermann, EPB |
| Licence | Apache-2.0 |

### Luchs A and Luchs B at a glance

| | Luchs A | Luchs B |
|---|---|---|
| Built for | compact, versatile: four builds, sideways and on-the-spot motion | demanding outdoor duty: 40 km/h, 300 mm clearance, desert / cooling builds |
| Protocol | Luchs A v1.1 (1 Mbit/s) | **LCI v1.0** (1 Mbit/s) · VCU upper interface V2.6 for units before LCI firmware |
| Launch | `luchs_a.launch.py build:=df\|fa\|da\|4ws` | `luchs_b.launch.py [protocol:=legacy_b]` |
| Motion models | differential · front / dual Ackermann · four-wheel steer | dual Ackermann (default) · front Ackermann |
| Host liveness | command watchdog in the driver | command watchdog in the driver **plus** chassis heartbeat (200 ms) |
| Chassis limits | static (parameters) | **live** (slope, temperature, battery, faults), applied by the driver |
| Extra feedback | wheel angles (4WS), lamp and light/rain sensor | chassis IMU (`imu/data_raw`), EPB / EPS / brake, motor temperatures, model and firmware version |
| Host requests | — | e-stop, park, payload power, speed cap (services) |
| Description | `luchs_a.urdf.xacro config:=…` (A-4WS from CAD) | `luchs_b.urdf.xacro` (envelope until CAD release) |

---

## Repository

| Package | What it is |
|---|---|
| [`luchs_sdk`](luchs_sdk) | ROS-free C++17 library: CAN protocol codecs (Luchs A, LCI, Luchs B VCU), SocketCAN transport, steering kinematics, thread-safe chassis client with watchdogs and heartbeat, built-in chassis simulators, the `luchs_cli` tool and Python examples. |
| [`luchs_msgs`](luchs_msgs) | `ChassisState`, `SafetyState`, `LampCommand`, `DriveCommand`, `SetMotionModel`, `SetPayloadPower`, `SetSpeedLimit`. |
| [`luchs_driver`](luchs_driver) | The ROS 2 node (also a composable component). |
| [`luchs_description`](luchs_description) | URDF / xacro for the four Luchs A builds (meshes from the A-4WS CAD) and Luchs B, RViz view. |
| [`luchs_bringup`](luchs_bringup) | Launch files for Luchs A and Luchs B, CAN setup script, udev rule, systemd units. |
| [`luchs_teleop`](luchs_teleop) | Gamepad configuration (teleop_twist_joy). |
| [`luchs`](luchs) | Metapackage. |
| [`dbc`](dbc) | DBC files for CAN tools: Luchs A v1.1, LCI v1.0 draft r3, Luchs B VCU V2.6 (checked against the SDK test vectors). |
| [`docs`](docs) | CAN setup, protocol references (Luchs A, Luchs B), integration guide, troubleshooting. |

---

## Quick start

### 1. Build

```bash
source /opt/ros/jazzy/setup.bash            # or humble
mkdir -p ~/luchs_ws/src && cd ~/luchs_ws/src
git clone <repository-url> luchs_ros2
cd ~/luchs_ws
rosdep install --from-paths src --ignore-src -y
colcon build --symlink-install
source install/setup.bash
```

### 2. Try it without a vehicle

The driver has a built-in chassis simulator (`dry_run:=true`), which speaks the same CAN protocol as the vehicle:

```bash
ros2 launch luchs_bringup luchs_a.launch.py build:=4ws dry_run:=true    # Luchs A-4WS
ros2 launch luchs_bringup luchs_b.launch.py dry_run:=true               # Luchs B (LCI)
ros2 run teleop_twist_keyboard teleop_twist_keyboard        # second terminal; Shift = sideways (A-4WS)
ros2 launch luchs_description display.launch.py config:=b   # optional: model in RViz (df|fa|da|4ws|b)
```

The Luchs B simulator follows LCI: it stops the vehicle when the heartbeat stops, latches an e-stop request, derates with a host speed cap and reports it in `~/state`.

### 3. Connect the vehicle

**Luchs A**

1. Connect the USB-CAN adapter to the signal expansion port under the magnetic cover at the rear of the deck (DB9 cable: orange CAN-H, yellow CAN-L, red GND; see [docs/can_setup.md](docs/can_setup.md)).
2. Bring the interface up at 1 Mbit/s:
   ```bash
   sudo ./src/luchs_ros2/luchs_bringup/scripts/setup_can.sh can0
   candump can0          # chassis feedback 0x5B5 ... 0x5BC should scroll
   ```
3. Set the **mode selector** on the chassis to host (automatic) control. The remote-control transmitter always has priority.
4. Start the driver for your build (`df`, `fa`, `da` or `4ws`):
   ```bash
   ros2 launch luchs_bringup luchs_a.launch.py build:=4ws can_interface:=can0
   ros2 launch luchs_bringup luchs_a.launch.py build:=4ws teleop:=true   # with a gamepad, hold LB
   ```

**Luchs B**

1. Connect the USB-CAN adapter to the customer CAN (LCI) — see [docs/can_setup.md](docs/can_setup.md).
2. `sudo ./src/luchs_ros2/luchs_bringup/scripts/setup_can.sh can0` and check `candump can0`: 0x5B0 … 0x5C1 should scroll, 0x5BF once a second.
3. Transmitter on, switch C down: automatic mode. Switch C up or switch A takes control back at any time.
4. Start the driver:
   ```bash
   ros2 launch luchs_bringup luchs_b.launch.py can_interface:=can0
   ros2 launch luchs_bringup luchs_b.launch.py protocol:=legacy_b    # units before LCI firmware, see docs/protocol_luchs_b.md
   ```

**Before the first drive:** lift the wheels or clear the area, keep the emergency stop in reach, and start with the default limits (Luchs A 2.0 m/s, 1.5 rad/s; Luchs B 2.0 m/s, 1.0 rad/s).

---

## ROS interface (`luchs_driver`)

| | Topic / service | Type |
|---|---|---|
| in | `cmd_vel` | `geometry_msgs/Twist` (or `TwistStamped`, `cmd_vel_stamped:=true`) |
| in | `~/drive_command` | `luchs_msgs/DriveCommand`: motion model and explicit steering angles |
| in | `~/lamps` | `luchs_msgs/LampCommand` |
| out | `odom` + TF `odom → base_footprint` | `nav_msgs/Odometry` |
| out | `joint_states` | `sensor_msgs/JointState` (steering and wheel joints) |
| out | `~/state` | `luchs_msgs/ChassisState` |
| out | `~/safety` | `luchs_msgs/SafetyState` (e-stops, bumpers, ultrasonic) |
| out | `battery_state` | `sensor_msgs/BatteryState` |
| out | `imu/data_raw` | `sensor_msgs/Imu` (Luchs B, LCI: chassis IMU, no orientation) |
| out | `/diagnostics` | `diagnostic_msgs/DiagnosticArray` |
| srv | `~/reset_odometry` | `std_srvs/Trigger` |
| srv | `~/set_motion_model` | `luchs_msgs/SetMotionModel` |
| srv | `~/estop`, `~/park` | `std_srvs/SetBool` (Luchs B) |
| srv | `~/set_payload_power`, `~/set_speed_limit` | `luchs_msgs/SetPayloadPower`, `SetSpeedLimit` (Luchs B, LCI) |

All parameters, with defaults and units: [luchs_driver/README.md](luchs_driver/README.md). Parameter files: `luchs_driver/config/luchs_a_<build>.yaml`, `luchs_driver/config/luchs_b.yaml`.

### Motion models

| Build | Models | `cmd_vel` uses |
|---|---|---|
| A-DF | differential | `linear.x`, `angular.z` |
| A-FA | front Ackermann · differential (turn on the spot) | `linear.x`, `angular.z` (at the rear axle) |
| A-DA | dual Ackermann · front Ackermann · differential | `linear.x`, `angular.z` |
| A-4WS | four-wheel steer (default) · dual Ackermann · front Ackermann · differential | `linear.x`, `linear.y`, `angular.z` |
| B | dual Ackermann (default) · front Ackermann | `linear.x`, `angular.z` (no turning on the spot) |

A request the chassis cannot follow is reduced: beyond the steering range the forward speed is kept and the turn scaled; beyond a speed limit (parameter or Luchs B live limit) an Ackermann path keeps its curvature. `~/state.command_limited` reports it.

### Safety behaviour

| Event | Reaction |
|---|---|
| No command for `control.cmd_timeout` (0.5 s) | ramp to zero, then gear P |
| No chassis feedback for `control.feedback_timeout` (0.5 s) | command zero, diagnostics ERROR |
| Driver shutdown (Ctrl-C, crash of the node process) | zero speed + gear P sent three times |
| Emergency stop, ultrasonic stop, bumper | handled by the chassis; reported on `~/safety` and diagnostics |
| Luchs B: driver process hangs or the host loses power | heartbeat stops; the chassis stops under control within 200 ms and applies the EPB |
| Luchs B: chassis derates (slope, temperature, battery, fault) | live limits applied before sending; reason in `~/state.limit_reason_text` |

These are software functions on top of the chassis protections. They do not replace the emergency stop or a risk assessment of the complete robot.

---

## Tools without ROS

```bash
luchs_cli dump    -i can0                  # every frame, decoded
luchs_cli monitor -i can0 --raw            # live state table with raw values
luchs_cli encode  --build 4ws --vx 0.4 --vy 0.2 --wz 0.3   # what one cycle sends
luchs_cli drive   -i can0 --build 4ws --vx 0.2 --seconds 2 --yes
luchs_cli monitor -i can0 --build b                    # Luchs B (LCI): limits, state, IMU, EPB/EPS, version
luchs_cli drive   --build b --vx 0.5 --wz 0.2 --yes --sim   # against the simulator
```

Python (python-can + cantools): `luchs_sdk/examples/python/luchs_monitor.py`, `luchs_drive.py`.
C++ without ROS: link `luchs_sdk::luchs_sdk` and use `luchs_sdk::Chassis` (see [luchs_sdk/README.md](luchs_sdk/README.md)).

---

## Firmware-dependent settings

Luchs A: a few protocol details differ between chassis firmware releases. They are parameters, so a vehicle is matched without rebuilding. Defaults follow the reference configuration. Check them once per vehicle: [docs/protocol_luchs_a.md](docs/protocol_luchs_a.md) explains each one and the five-minute check with `luchs_cli monitor --raw`.

| Parameter | Default |
|---|---|
| `protocol.wheel_steer_cmd_id` | `1443` (0x5A3; lamps on 0x5A2) |
| `protocol.wheel_steer_cmd_order` / `wheel_steer_fb_order` / `wheel_speed_fb_order` | `lf_rf_lr_rr` / `lf_lr_rf_rr` / `lf_lr_rf_rr` |
| `protocol.wheel_speed_scale`, `ultrasonic_scale`, `battery_*_scale` | see the protocol document |

---

## Coordinate frames

`odom → base_footprint → base_link → {front,rear}_{left,right}_steer_link → …_wheel_link`, plus `top_plate_link`, `imu_link` (and `rail_left_link`, `rail_right_link` on Luchs A). Same names on both chassis, REP-103 axes. Mount payloads on the rails (A) or the deck (B); see [luchs_description/README.md](luchs_description/README.md).

## Versioning

Semantic versioning. The driver prints its version at start-up; `luchs_cli version` prints the SDK version. Changes: [CHANGELOG.md](CHANGELOG.md).

## Support

RJ Tech Limited · sales@rjtech-offroad.com · [rjtech-offroad.com](https://www.rjtech-offroad.com)
TerraAgent Robotics (TAR) · robot software and integration

When reporting a problem, include the driver log, `ros2 topic echo --once /diagnostics`, the build (`df`/`fa`/`da`/`4ws`/`b`), the protocol and a short `candump -l can0` capture.

## Licence

Apache License 2.0, see [LICENSE](LICENSE).
